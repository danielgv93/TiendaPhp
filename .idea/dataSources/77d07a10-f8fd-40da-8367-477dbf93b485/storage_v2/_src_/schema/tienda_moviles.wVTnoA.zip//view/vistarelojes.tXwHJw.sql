create view vistarelojes as
select `d`.`id_dispositivo` AS `id_dispositivo`,
       `d`.`modelo`         AS `modelo`,
       `d`.`precio`         AS `precio`,
       `d`.`gama`           AS `gama`,
       `d`.`anio`           AS `anio`,
       `d`.`ram`            AS `ram`,
       `d`.`almacenamiento` AS `almacenamiento`,
       `d`.`procesador`     AS `procesador`,
       `d`.`bateria`        AS `bateria`,
       `d`.`pulgadas`       AS `pulgadas`,
       `r`.`id_reloj`       AS `id_reloj`,
       `r`.`sim`            AS `sim`
from (`tienda_moviles`.`dispositivos` `d`
         join `tienda_moviles`.`relojes` `r` on (`d`.`id_dispositivo` = `r`.`id_reloj`));

